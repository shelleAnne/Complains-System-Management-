﻿Imports System.Data.OleDb
Imports System.IO

Public Class USER_LOG
    Dim connectstr As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\skyImperial1.accdb"
    Dim connect As New OleDbConnection(connectstr)
    Dim cmd As OleDbCommand
    Dim adapter As OleDbDataAdapter
    Dim mytable As DataTable = New DataTable()
    Dim dr As OleDbDataReader
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Form1.Show()
        Me.Hide()
    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = True Then
            TextBox2.UseSystemPasswordChar = False
        Else
            TextBox2.UseSystemPasswordChar = True
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If TextBox1.Text = "" Or TextBox2.Text = "" Then
            MessageBox.Show("All fields are required!")
        Else
            Try

                connect.Open()
                Using cmd As New OleDbCommand("SELECT * FROM [REGISTER] WHERE [USERNAME] = @USERNAME OR [PASSWORD] = @PASSWORD", connect)
                    cmd.Parameters.AddWithValue("@USERNAME", OleDbType.VarChar).Value = TextBox1.Text.Trim
                    cmd.Parameters.AddWithValue("@PASSWORD", OleDbType.VarChar).Value = TextBox2.Text.Trim

                    Dim ds As New OleDbDataAdapter(cmd)
                    Dim REGISTER As New DataTable
                    ds.Fill(REGISTER)

                    If REGISTER.Rows.Count > 0 Then
                        DASH_USER.Show()
                        Me.Hide()
                    Else
                        MessageBox.Show("Invalid username or password!")
                    End If
                End Using
            Catch ex As Exception
                MessageBox.Show("An error occurred: " & ex.Message)
            End Try
        End If
    End Sub

End Class