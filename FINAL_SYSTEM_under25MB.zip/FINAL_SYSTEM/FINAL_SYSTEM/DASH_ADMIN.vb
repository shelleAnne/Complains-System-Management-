﻿Imports System.Data.OleDb
Imports System.IO

Public Class DASH_ADMIN
    Dim connectstr As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\skyImperial1.accdb"
    Dim connect As New OleDbConnection(connectstr)
    Dim cmd As OleDbCommand
    Dim adapter As OleDbDataAdapter
    Dim mytable As DataTable = New DataTable()
    Dim dr As OleDbDataReader
    Private Sub Populate(NAME As String, USERNAME As String, PASSWORD As String)
        Dim row As String() = New String() {NAME, USERNAME, PASSWORD}
        DataGridView1.Rows.Add(row)
    End Sub

    Private Sub Retrieve()
        DataGridView1.Rows.Clear()
        connect.Close()
        connect.Open()
        Dim sql As String = "SELECT NAME, USERNAME, PASSWORD " &
                    "FROM REGISTER "


        cmd = New OleDbCommand(sql, connect)

        Try
            adapter = New OleDbDataAdapter(cmd)
            adapter.Fill(mytable)

            For Each row As DataRow In mytable.Rows
                Populate(row("NAME").ToString(), row("USERNAME").ToString(), row("PASSWORD").ToString())
            Next

            mytable.Rows.Clear()
            connect.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
            connect.Close()
        End Try
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        Form1.Show()
        Me.Hide()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        MAIN.Show()
        Me.Hide()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        SEC_DASH.Show()
        Me.Hide()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        BILLING.Show()
        Me.Hide()
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Using connection As OleDbConnection = New OleDbConnection(connectstr)
            Dim sql As String = "INSERT INTO REGISTER ([NAME], [USERNAME], [PASSWORD]) VALUES (@NAME, @USERNAME, @PASSWORD)"
            Using command As New OleDbCommand(sql, connection)
                command.Parameters.AddWithValue("@NAME", TextBox1.Text)
                command.Parameters.AddWithValue("@USERNAME", TextBox2.Text)
                command.Parameters.AddWithValue("@PASSWORD", TextBox3.Text)

                connection.Open()
                command.ExecuteNonQuery()
                connection.Close()

                MessageBox.Show("Successfully saved!")
                TextBox1.Clear()
                TextBox2.Clear()
                TextBox3.Clear()
            End Using
        End Using
    End Sub


    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        If e.RowIndex >= 0 Then
            Dim selectedRow As DataGridViewRow = DataGridView1.Rows(e.RowIndex)
            TextBox1.Text = selectedRow.Cells(0).Value.ToString()
            TextBox2.Text = selectedRow.Cells(1).Value.ToString()
            TextBox3.Text = selectedRow.Cells(2).Value.ToString()

        End If


    End Sub

    Private Sub DASH_ADMIN_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        DataGridView1.ReadOnly = True
        DataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect

        DataGridView1.ColumnCount = 3
        DataGridView1.Columns(0).Name = "NAME"
        DataGridView1.Columns(1).Name = "USERNAME"
        DataGridView1.Columns(2).Name = "PASSWORD"
    End Sub

    Private Sub Button11_Click(sender As Object, e As EventArgs) Handles Button11.Click
        Retrieve()
    End Sub

    Private Sub Button12_Click(sender As Object, e As EventArgs) Handles Button12.Click
        If DataGridView1.SelectedRows.Count > 0 Then
            Dim selectedRow As DataGridViewRow = DataGridView1.SelectedRows(0)

            ' Update the values in the selected row
            selectedRow.Cells(0).Value = TextBox1.Text
            selectedRow.Cells(1).Value = TextBox2.Text
            selectedRow.Cells(2).Value = TextBox3.Text

            MessageBox.Show("Row updated successfully!")
            TextBox1.Clear()
            TextBox2.Clear()
            TextBox3.Clear()
        End If
    End Sub

    Private Sub Button13_Click(sender As Object, e As EventArgs) Handles Button13.Click
        Dim searchKeyword As String = TextBox4.Text.Trim()

        ' Loop through each row in the DataGridView
        For Each row As DataGridViewRow In DataGridView1.Rows
            ' Check if the value in any cell of the current row contains the search keyword
            For Each cell As DataGridViewCell In row.Cells
                If cell.Value IsNot Nothing AndAlso cell.Value.ToString().Contains(searchKeyword) Then
                    ' If a match is found, select the row and exit the loop
                    row.Selected = True
                    Exit For
                End If
            Next
        Next
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        TextBox4.Clear()
    End Sub
End Class