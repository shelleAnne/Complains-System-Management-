﻿Imports System.Data.OleDb
Imports System.IO

Public Class MAIN_DASH
    Dim connectstr As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\skyImperial1.accdb"
    Dim connect As New OleDbConnection(connectstr)
    Dim cmd As OleDbCommand
    Dim adapter As OleDbDataAdapter
    Dim mytable As DataTable = New DataTable()

    Private Sub Populate(NAME As String, UNIT_NO As String, FLOOR As String, [DATE] As String, TYPE_COMPLAIN As String, ALERT As String, DATE_PROCESS As String, COST_AMOUNT As String, STATUES As String)
        Dim row As String() = New String() {NAME, UNIT_NO, FLOOR, [DATE], TYPE_COMPLAIN, ALERT, DATE_PROCESS, COST_AMOUNT, STATUES}
        DataGridView2.Rows.Add(row)
    End Sub

    Private Sub Retrieve()
        DataGridView2.Rows.Clear()
        connect.Close()
        connect.Open()
        Dim sql As String = "SELECT NAME, UNIT_NO, FLOOR, [DATE], TYPE_COMPLAIN, ALERT, DATE_PROCESS, COST_AMOUNT, STATUES " &
                "FROM MAINTENANCE "

        cmd = New OleDbCommand(sql, connect)

        Try
            adapter = New OleDbDataAdapter(cmd)
            adapter.Fill(mytable)

            For Each row As DataRow In mytable.Rows
                Populate(row("NAME").ToString(), row("UNIT_NO").ToString(), row("FLOOR").ToString(), row("DATE").ToString(), row("TYPE_COMPLAIN").ToString(), row("ALERT").ToString(), row("DATE_PROCESS").ToString(), row("COST_AMOUNT").ToString(), row("STATUES").ToString())
            Next

            mytable.Rows.Clear()
            connect.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
            connect.Close()
        End Try
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        DASH_ADMIN.Show()
        Me.Hide()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Retrieve()
    End Sub

    Private Sub MAIN_DASH_Load(sender As Object, e As EventArgs)
        DataGridView2.ReadOnly = True
        DataGridView2.SelectionMode = DataGridViewSelectionMode.FullRowSelect

        DataGridView2.ColumnCount = 9
        DataGridView2.Columns(0).Name = "NAME"
        DataGridView2.Columns(1).Name = "UNIT_NO"
        DataGridView2.Columns(2).Name = "FLOOR"
        DataGridView2.Columns(3).Name = "DATE"
        DataGridView2.Columns(4).Name = "TYPE_COMPLAIN"
        DataGridView2.Columns(5).Name = "ALERT"
        DataGridView2.Columns(6).Name = "DATE_PROCESS"
        DataGridView2.Columns(7).Name = "COST_AMOUNT"
        DataGridView2.Columns(8).Name = "STATUES"

        Retrieve()
    End Sub


End Class
