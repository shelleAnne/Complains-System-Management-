﻿Imports System.Data.OleDb
Imports System.IO

Public Class SEC_DASH
    Dim connectstr As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\skyImperial1.accdb"
    Dim connect As New OleDbConnection(connectstr)
    Dim cmd As OleDbCommand
    Dim adapter As OleDbDataAdapter
    Dim mytable As DataTable = New DataTable()
    Private dgReport As Object

    Private Sub Populate(NAME As String, UNIT_NO As String, FLOOR As String, [DATE] As String, TYPECOMPLAIN As String, ALERT As String, DATEP_ROCESS As String, STATUES As String)
        Dim row As String() = New String() {NAME, UNIT_NO, FLOOR, [DATE], TYPECOMPLAIN, ALERT, DATEP_ROCESS, STATUES}
        DataGridView1.Rows.Add(row)
    End Sub

    Private Sub Retrieve()
        DataGridView1.Rows.Clear()
        connect.Close()
        connect.Open()
        Dim sql As String = "SELECT NAME, UNIT_NO, FLOOR, [DATE], TYPE_COMPLAIN, ALERT, DATE_PROCESS, STATUES " &
                "FROM SECURITY "

        cmd = New OleDbCommand(sql, connect)

        Try
            adapter = New OleDbDataAdapter(cmd)
            adapter.Fill(mytable)

            For Each row As DataRow In mytable.Rows
                Populate(row("NAME").ToString(), row("UNIT_NO").ToString(), row("FLOOR").ToString(), row("DATE").ToString(), row("TYPE_COMPLAIN").ToString(), row("ALERT").ToString(), row("DATE_PROCESS").ToString(), row("STATUES").ToString())
            Next

            mytable.Rows.Clear()
            connect.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
            connect.Close()
        End Try
    End Sub






    Private Sub SEC_DASH_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        DataGridView1.ReadOnly = True
        DataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect

        DataGridView1.ColumnCount = 8
        DataGridView1.Columns(0).Name = "NAME"
        DataGridView1.Columns(1).Name = "UNIT_NO"
        DataGridView1.Columns(2).Name = "FLOOR"
        DataGridView1.Columns(3).Name = "DATE"
        DataGridView1.Columns(4).Name = "TYPE_COMPLAIN"
        DataGridView1.Columns(5).Name = "ALERT"
        DataGridView1.Columns(6).Name = "DATE_PROCESS"
        DataGridView1.Columns(7).Name = "STATUES"

        Retrieve()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        DASH_ADMIN.Show()
        Me.Hide()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) 
        Retrieve()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        dgReport.Current.cells(5).Value = "Cancelled"
    End Sub

    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        Dim data As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source="
        File.WriteAllText("\skyImperial1.accdb", data)

        MessageBox.Show("Data saved successfully.")
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        Dim DataGridView As DataGridView = DataGridView1
        Dim columnIndex As Integer = 7

        If DataGridView.SelectedRows.Count > 0 Then

            Dim selectedRow As DataGridViewRow = DataGridView.SelectedRows(0)

            selectedRow.Cells(columnIndex).Value = "COMPLETE"
        End If
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Dim DataGridView As DataGridView = DataGridView1
        Dim columnIndex As Integer = 7

        If DataGridView.SelectedRows.Count > 0 Then

            Dim selectedRow As DataGridViewRow = DataGridView.SelectedRows(0)

            selectedRow.Cells(columnIndex).Value = "PENDING"
        End If
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        Dim DataGridView As DataGridView = DataGridView1
        Dim columnIndex As Integer = 7

        If DataGridView.SelectedRows.Count > 0 Then

            Dim selectedRow As DataGridViewRow = DataGridView.SelectedRows(0)

            selectedRow.Cells(columnIndex).Value = "ONGOING"
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim DataGridView As DataGridView = DataGridView1
        Dim columnIndex As Integer = 5

        If DataGridView.SelectedRows.Count > 0 Then

            Dim selectedRow As DataGridViewRow = DataGridView.SelectedRows(0)

            selectedRow.Cells(columnIndex).Value = "1"
        End If
    End Sub

    Private Sub Button4_Click_1(sender As Object, e As EventArgs) Handles Button4.Click
        Dim DataGridView As DataGridView = DataGridView1
        Dim columnIndex As Integer = 5

        If DataGridView.SelectedRows.Count > 0 Then

            Dim selectedRow As DataGridViewRow = DataGridView.SelectedRows(0)

            selectedRow.Cells(columnIndex).Value = "2"
        End If
    End Sub

    Private Sub Button5_Click_1(sender As Object, e As EventArgs) Handles Button5.Click
        Dim DataGridView As DataGridView = DataGridView1
        Dim columnIndex As Integer = 5

        If DataGridView.SelectedRows.Count > 0 Then

            Dim selectedRow As DataGridViewRow = DataGridView.SelectedRows(0)

            selectedRow.Cells(columnIndex).Value = "3"
        End If
    End Sub
End Class
