﻿Imports System.Data.SqlClient
Imports System.Data.OleDb
Imports System.IO
Public Class DASH_USER
    Dim connectstr As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\skyImperial1.accdb"
    Dim connect As New OleDbConnection(connectstr)
    Dim cmd As OleDbCommand
    Dim adapter As OleDbDataAdapter
    Dim mytable As DataTable = New DataTable()
    Dim dr As OleDbDataReader


    Private Sub DisplayNameFromDatabase()
        Dim connectstr As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\skyImperial1.accdb"
        Dim query As String = "SELECT REGISTER FROM NAME"

        Using connection As New SqlConnection(connectstr)
            Using command As New SqlCommand(query, connection)
                connection.Open()

                Dim reader As SqlDataReader = command.ExecuteReader()

                If reader.Read() Then
                    Dim name As String = reader.GetString(0)
                    Label1.Text = "Name: " & name
                End If

                reader.Close()
            End Using
        End Using
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click
        DisplayNameFromDatabase()
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        Application.Restart()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        MAIN_COMP.Show()
        Me.Hide()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        SEC_COMP.Show()
        Me.Hide()
    End Sub

End Class