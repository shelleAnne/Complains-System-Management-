﻿Imports System.Data.OleDb
Imports System.IO

Public Class MAIN_COMP
    Dim connectstr As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\skyImperial1.accdb"
    Dim connection As New OleDbConnection(connectstr)
    Dim cmd As OleDbCommand
    Dim adapter As OleDbDataAdapter
    Dim mytable As DataTable = New DataTable()
    Dim dr As OleDbDataReader
    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        DASH_USER.Show()
        Me.Hide()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim sql As String = "INSERT INTO MAINTENANCE ([NAME], [UNIT_NO], [FLOOR], [DATE], [TYPE_COMPLAIN]) VALUES (@NAME, @UNIT_NO, @FLOOR, @DATE, @TYPE_COMPLAIN)"
        Using command As New OleDbCommand(sql, connection)
            command.Parameters.AddWithValue("@NAME", TextBox1.Text)
            command.Parameters.AddWithValue("@UNIT NO", TextBox2.Text)
            command.Parameters.AddWithValue("@FLOOR", TextBox3.Text)
            command.Parameters.AddWithValue("@DATE", ComboBox1.Text & "/" & ComboBox2.Text & "/" & ComboBox3.Text)
            command.Parameters.AddWithValue("@TYPE_COMPLAIN", TextBox4.Text)

            connection.Open()
            command.ExecuteNonQuery()
            connection.Close()

            MessageBox.Show("Successfully saved!")
            TextBox1.Clear()
            TextBox2.Clear()
            TextBox3.Clear()
            TextBox4.Clear()
        End Using
    End Sub


End Class