﻿Imports System.Data.OleDb
Imports System.IO

Public Class BILLING
    Dim connectstr As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\skyImperial1.accdb"
    Dim connect As New OleDbConnection(connectstr)
    Dim cmd As OleDbCommand
    Dim adapter As OleDbDataAdapter
    Dim mytable As DataTable = New DataTable()

    Private Sub Populate(NAME As String, UNIT_NO As String, FLOOR As String, [DATE] As String, DATE_PROCESS As String, COST_AMOUNT As String, STATUES As String)
        Dim row As String() = New String() {NAME, UNIT_NO, FLOOR, [DATE], DATE_PROCESS, COST_AMOUNT, STATUES}
        DataGridView1.Rows.Add(row)
    End Sub

    Private Sub Retrieve()
        DataGridView1.Rows.Clear()
        connect.Close()
        connect.Open()
        Dim sql As String = "SELECT NAME, UNIT_NO, FLOOR, [DATE], ALERT, DATE_PROCESS, COST_AMOUNT, STATUES " &
                "FROM MAINTENANCE "

        cmd = New OleDbCommand(sql, connect)

        Try
            adapter = New OleDbDataAdapter(cmd)
            adapter.Fill(mytable)

            For Each row As DataRow In mytable.Rows
                Populate(row("NAME").ToString(), row("UNIT_NO").ToString(), row("FLOOR").ToString(), row("DATE").ToString(), row("DATE_PROCESS").ToString(), row("COST_AMOUNT").ToString(), row("STATUES").ToString())
            Next

            mytable.Rows.Clear()
            connect.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
            connect.Close()
        End Try
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        DASH_ADMIN.Show()
        Me.Hide()
    End Sub

    Private Sub BILLING_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        DataGridView1.ReadOnly = True
        DataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect

        DataGridView1.ColumnCount = 7
        DataGridView1.Columns(0).Name = "NAME"
        DataGridView1.Columns(1).Name = "UNIT_NO"
        DataGridView1.Columns(2).Name = "FLOOR"
        DataGridView1.Columns(3).Name = "DATE"
        DataGridView1.Columns(4).Name = "DATE_PROCESS"
        DataGridView1.Columns(5).Name = "COST_AMOUNT"
        DataGridView1.Columns(6).Name = "STATUES"

        Retrieve()
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        If e.RowIndex >= 0 Then
            Dim selectedRow As DataGridViewRow = DataGridView1.Rows(e.RowIndex)
            Dim rowData As String = ""

            For Each cell As DataGridViewCell In selectedRow.Cells
                rowData += cell.Value.ToString() & " "
            Next

            TextBox5.Text = rowData.Trim()
        End If
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Dim printDialog As New PrintDialog()

        ' Set the print document
        Dim printDocument As New Printing.PrintDocument()
        AddHandler printDocument.PrintPage, AddressOf PrintDocument_PrintPage
        printDialog.Document = printDocument

        ' Show the print dialog and print if the user selects OK
        If printDialog.ShowDialog() = DialogResult.OK Then
            printDocument.Print()
        End If
    End Sub

    Private Sub PrintDocument_PrintPage(sender As Object, e As Printing.PrintPageEventArgs)
        Dim printFont As New Font("Arial", 12)
        Dim textToPrint As String = TextBox5.Text

        ' Calculate the margins and print area
        Dim leftMargin As Integer = e.MarginBounds.Left
        Dim topMargin As Integer = e.MarginBounds.Top
        Dim printAreaWidth As Integer = e.MarginBounds.Width
        Dim printAreaHeight As Integer = e.MarginBounds.Height

        ' Print the text
        e.Graphics.DrawString(textToPrint, printFont, Brushes.Black, leftMargin, topMargin)

        ' Check if there are more pages to print
        e.HasMorePages = False
    End Sub
End Class